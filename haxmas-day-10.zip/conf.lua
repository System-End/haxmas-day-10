function love.conf(t)
    t.title = "Enhanced Runner"
    t.version = "11.4"
    t.window.width = 800
    t.window.height = 400
    t.window.resizable = false
end
