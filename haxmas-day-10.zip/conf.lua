function love.conf(t)
    t.title = "Enhanced Runner"
    t.version = "11.0"
    t.window.width = 800
    t.window.height = 400
    t.window.resizable = false
end
